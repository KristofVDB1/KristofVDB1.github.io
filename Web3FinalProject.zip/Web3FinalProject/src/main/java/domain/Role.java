package domain;

public enum Role {

    ADMINISTRATOR("admin"),
    NORMAL("normal");

    private String roleDescription;

    Role(String roleDescription){
        this.roleDescription = roleDescription;
    }

    public String getRoleDescription() {
        return this.roleDescription;
    }

}

