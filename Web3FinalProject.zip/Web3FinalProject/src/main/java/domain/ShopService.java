package domain;

import java.sql.SQLException;
import java.util.List;
import java.util.Properties;
import db.*;
import db.PersonDbInMemory;
import db.PersonDbOnline;
import db.ProductDbInMemory;

public class ShopService {
    private PersonDb personDb = new PersonDbOnline();
    private ProductDb productDb = new ProductDbOnline();


    public ShopService(Properties properties) throws DbException{
        try{
            this.personDb= new PersonDbOnline();
        }catch(Exception E){
            throw new DbException(E.getMessage());
        }
        try{
            this.productDb= new ProductDbOnline();
        }catch(Exception E){
            throw new DbException(E.getMessage());
        }
    }

    public ShopService() {

    }
    public Person displayUser(String email) { return getPersonDb().getPerson(email);}
    public Person getPerson(String personId) {
        return getPersonDb().get(personId);
    }
    public List<Person> getPersons() {
        return getPersonDb().getAll();
    }
    public void addPerson(Person person, String role) {
        getPersonDb().add(person, role);
    }
    public void updatePerson(Person person) {
        getPersonDb().update(person);
    }
    public void deletePerson(String id) {
        getPersonDb().delete(id);
    }
    private PersonDb getPersonDb() {
        return personDb;
    }
    private ProductDb getProductDb(){
        return productDb;
    }
    public List<Product> getProducts() {
        return getProductDb().getAll();
    }
    public List<Product> getProductsOrdered() {
        return getProductDb().sorteer();
    }
    public Product getProduct(int productId){
        return getProductDb().get(productId);
    }
    public void addProduct(Product product){
        getProductDb().add(product);
    }
    public void updateProducts(Product product){
        getProductDb().update(product);
    }
    public void deleteProduct(int id){
        getProductDb().delete(id);
    }




}
