package domain;
import db.PersonDbOnline;
import db.*;
import domain.Role;

public class Main {
    private ShopService service;

    public static void main(String[] args){
        ShopService service = new ShopService();
        Person person = service.displayUser("anna@gmail.com");
        Person person2 = new Person("14","krissytfo@hormail.com", "lel", "kristof", "vdb", Role.ADMINISTRATOR);
        System.out.println(person);
        System.out.println(person2 + "\n");
        person2.setSalt(person.getSalt());
        System.out.println(person);
        System.out.println(person2+ "\n");
        person2.setPassword(person.hashPassword(person2.getPassword(), person.getSalt()));
        System.out.println(person);
        System.out.println(person2+ "\n");
        System.out.println(person2.isCorrectPassword("lel"));



    }
}
