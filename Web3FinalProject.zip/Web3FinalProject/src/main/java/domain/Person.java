package domain;

import sun.plugin2.message.Message;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;


public class Person {
    private String userid;
    private String email;
    private String salt;
    private String password;
    private String firstName;
    private String lastName;
    private Role role;

    public Person(String userid, String email, String password, String firstName, String lastName, Role role) {
        setUserid(userid);
        setEmail(email);
        setPassword(password);
        setFirstName(firstName);
        setLastName(lastName);
        setRole(role);
    }

    public Person(String userid, String email, String password, String firstName, String lastName, String salt, Role role) {
        setUserid(userid);
        setEmail(email);
        setPassword(password);
        setFirstName(firstName);
        setLastName(lastName);
        setSalt(salt);
        setRole(role);
    }

    public Person() {
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userID) {
        if (userID.isEmpty() || userID == null) {
            throw new DomainException("invalid userID");
        }
        this.userid = userID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstname) {
        if (firstname.isEmpty() || firstname == null) {
            throw new DomainException("invalid firstname");
        }
        this.firstName = firstname;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastname) {
        if (lastname.isEmpty() || lastname == null) {
            throw new DomainException("invalid lastname");
        }
        this.lastName = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email.isEmpty() || email == null) {
            throw new DomainException("invalid email");
        }
        this.email = email;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setPassword(String password) {
        if (password.isEmpty() || password == null) {
            throw new DomainException("invalid password");
        }
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setHashedPassword(String password) throws DomainException {
        if (password.isEmpty() || password == null) {
            throw new DomainException("invalid password");
        }

        this.password = hashPassword(password);
    }


    public String hashPassword(String password) throws DomainException {
        SecureRandom random = new SecureRandom();
        byte[] seed = random.generateSeed(20);

        String salt = new BigInteger(1, seed).toString(16);
        this.setSalt(salt);

        return hashPassword(password, salt);
    }

    public String hashPassword(String password, String salt) {
        MessageDigest crypt;
        try {
            crypt = MessageDigest.getInstance("SHA-512");
        } catch (NoSuchAlgorithmException e) {
            throw new DomainException(e.getMessage(), e);
        }
        crypt.reset();
        byte[] passwordBytes;
        try {
            passwordBytes = password.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new DomainException(e.getMessage());

        }
        crypt.update(passwordBytes);
        try {
            crypt.update(salt.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e1) {
            throw new DomainException(e1.getMessage());
        }
        byte[] digest = crypt.digest();
        BigInteger digestAsBigInteger = new BigInteger(1, digest);
        return digestAsBigInteger.toString(16);
    }



    public boolean isCorrectPassword(String password) {
        if(password == null || password.isEmpty()) {
            throw new DomainException("no password given you fuck");
        }
        return getPassword().equals(hashPassword(password, getSalt()));

    }

    @Override
    public String toString(){
        return "First name : " + getFirstName() + " Last name:  " + getLastName() + " Userid: " + getUserid() + ", Email: " + getEmail() + " ,Password " + getPassword() + " Salt " + this.getSalt() + " Role: " + getRole();
    }
}
