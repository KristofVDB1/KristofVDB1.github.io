package db;

import java.util.List;


import domain.Product;

public interface ProductDb {

    public Product get(int id);
    public List<Product> getAll();
    public void add(Product product);
    public void update(Product product);
    public void delete(int id);
    public List<Product> sorteer();
}
