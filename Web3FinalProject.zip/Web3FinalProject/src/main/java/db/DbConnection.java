package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbConnection {
    private static final String USERNAME = "r0368837";
    private static final String PASSWORD = "Klasfoto1007";
    private static final String URL = "jdbc:postgresql://gegevensbanken.khleuven.be:51617/2TX38?currentSchema=r0368837_webontwerp";


    public static Connection getConnection() {
        Properties properties = new Properties();
        properties.setProperty("user", USERNAME);
        properties.setProperty("password", PASSWORD);
        properties.setProperty("ssl", "true");
        properties.setProperty("sslfactory", "org.postgresql.ssl.NonValidatingFactory");

        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(URL, properties);
        } catch (ClassNotFoundException e) {
            throw new DbException("Driver error:" + e.getMessage());
        } catch (SQLException e) {
            throw new DbException("Error setting up connection:" + e.getMessage());
        }

    }
}
