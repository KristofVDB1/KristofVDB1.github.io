package db;
import java.util.List;

import domain.*;

public interface PersonDb {

    public Person get(String personId);
    public Person getPerson(String email);
    public List<Person> getAll();
    public void add(Person person, String role);
    public void update(Person person);
    public void delete(String personId);
}
