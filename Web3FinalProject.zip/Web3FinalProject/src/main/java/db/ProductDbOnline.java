package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import domain.Person;
import domain.Product;

public class ProductDbOnline implements ProductDb {
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;

    private void initializeConnection() {
        connection = DbConnection.getConnection();
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new DbException("SQL could not create statement" + e.getMessage());
        }
    }

    private void initializeConnection(String sql) {
        connection = DbConnection.getConnection();
        try {
            preparedStatement = connection.prepareStatement(sql);
        } catch (SQLException e) {
            throw new DbException("SQL could not create statement" + e.getMessage());
        }
    }

    private void closeConnection(AutoCloseable statement) {
        try {
            statement.close();
            connection.close();
        } catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    @Override
    public Product get(int id) {
        Product product = null;
        String sql = "SELECT productid,name,description,price FROM r0368837_webontwerp.product WHERE productid= ?";
        try  {
                this.initializeConnection(sql);
                preparedStatement.setInt(1,id);
                ResultSet result = preparedStatement.executeQuery();
            result.next();
                int productid = result.getInt("productid");
                String name = result.getString("name");
                String description = result.getString("description");
                double price = result.getDouble("price");
                product = new Product(productid, name, description, price);
            if(product == null){

                throw new DbException("dit product bestaat niet");
            }
            return product;
        } catch (SQLException E) {
            throw new DbException(E.getMessage(), E);
        }
    }

    @Override
    public List<Product> getAll() {
        List<Product> list = new ArrayList<>();
        try  {
            this.initializeConnection();
            ResultSet result = statement.executeQuery("SELECT * FROM r0368837_webontwerp.product");
            while (result.next()) {
                int productid = result.getInt("productid");
                String name = result.getString("name");
                String description = result.getString("description");
                double price = result.getDouble("price");
                Product product = new Product(productid, name, description, price);
                list.add(product);
            }
            return list;
        } catch (SQLException E) {
            throw new DbException(E.getMessage(), E);
        }
        finally {
            this.closeConnection(statement);
        }
    }

    @Override
    public void add(Product product) {
        String sql = "INSERT INTO r0368837_webontwerp.product (name, description, price)"
                + "VALUES(?,?,?)";
        try  {
            this.initializeConnection(sql);
            preparedStatement.setString(1, product.getName());
            preparedStatement.setString(2, product.getDescription());
            preparedStatement.setDouble(3,product.getPrice());
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new DbException(e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }

    }

    @Override
    public void update(Product product) {
        String sql = "UPDATE r0368837_webontwerp.product SET name = ?, description = ?, price = ? WHERE productid = ?";
        if (product == null) {
            throw new DbException("No product given to update");
        }
        try  {
            this.initializeConnection(sql);
            preparedStatement.setString(1, product.getName());
            preparedStatement.setString(2, product.getDescription());
            preparedStatement.setDouble(3, product.getPrice());
            preparedStatement.setInt(4,product.getProductId());
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }


    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM r0368837_webontwerp.product WHERE productid = ?";
        try  {
            this.initializeConnection(sql);
            preparedStatement.setInt(1, id);
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }

    }

    @Override
    public List<Product> sorteer() {
        List<Product> list = new ArrayList<>();
        try  {
            this.initializeConnection();
            ResultSet result = statement.executeQuery("SELECT * FROM r0368837_webontwerp.Product ORDER BY name");
            while (result.next()) {
                int productid = result.getInt("productid");
                String name = result.getString("name");
                String description = result.getString("description");
                double price = result.getDouble("price");
                Product product = new Product(productid, name, description, price);
                list.add(product);
            }
            return list;
        } catch (SQLException E) {
            throw new DbException(E.getMessage(), E);
        }
        finally {
            this.closeConnection(statement);
        }
    }
}
