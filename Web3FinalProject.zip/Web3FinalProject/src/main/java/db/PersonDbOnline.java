package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import domain.Person;
import domain.Role;

import javax.xml.transform.Result;

public class PersonDbOnline implements PersonDb {
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;

    private void initializeConnection() {
        connection = DbConnection.getConnection();
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            throw new DbException("SQL could not create statement" + e.getMessage());
        }
    }

    private void initializeConnection(String sql) {
        connection = DbConnection.getConnection();
        try {
            preparedStatement = connection.prepareStatement(sql);
        } catch (SQLException e) {
            throw new DbException("SQL could not create statement" + e.getMessage());
        }
    }

    private void closeConnection(AutoCloseable statement) {
        try {
            statement.close();
            connection.close();
        } catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    public PersonDbOnline() {}

    @Override
    public Person get(String personId) {
        Person person=null;
        String sql = "SELECT * FROM r0368837_webontwerp.person WHERE userid=?";
        try  {
            this.initializeConnection(sql);
            preparedStatement.setInt(1, Integer.parseInt(personId));
            ResultSet result = preparedStatement.executeQuery();
            while (result.next()) {
                Role roleEnum = Role.NORMAL;
                if (result.getString("role").equals("administrator")) {
                    roleEnum = Role.ADMINISTRATOR;
                }
                String userid = result.getString(1);
                String email = result.getString(2);
                String password = result.getString(3);
                String firstname = result.getString(4);
                String lastname = result.getString(5);
                String salt = result.getString(6);
                person = new Person(userid, email, password, firstname, lastname, salt, roleEnum);
            }
            if(person == null){

                throw new DbException("deze persoon bestaat niet");
            }
            return person;
        } catch (SQLException E) {
            throw new DbException(E.getMessage(), E);
        }
        finally {
            this.closeConnection(preparedStatement);
        }

    }

    @Override
    public List<Person> getAll() {
        List<Person> list = new ArrayList<>();
        try  {
            this.initializeConnection();
            ResultSet result = statement.executeQuery("SELECT * FROM r0368837_webontwerp.person");
            while (result.next()) {
                Role roleEnum = Role.NORMAL;
                if (result.getString("role").equals("administrator")) {
                    roleEnum = Role.ADMINISTRATOR;
                }
                String userid = result.getString("userid");
                String email = result.getString("email");
                String password = result.getString("password");
                String firstname = result.getString("firstName");
                String lastname = result.getString("lastname");
                String salt = result.getString("salt");
                Person person = new Person(userid, email, password, firstname, lastname, salt,roleEnum);
                list.add(person);
            }
            return list;
        } catch (SQLException E) {
            throw new DbException(E.getMessage(), E);
        }
        finally {
            this.closeConnection(statement);
        }
    }

    @Override
    public Person getPerson(String email) {
        Person person=null;
        String sql = "SELECT * FROM r0368837_webontwerp.person WHERE email = ?";
        try {
            this.initializeConnection(sql);
            preparedStatement.setString(1, email);
            ResultSet result = preparedStatement.executeQuery();
            while (result.next()) {
                Role roleEnum = Role.NORMAL;
                if (result.getString("role").equals("administrator")) {
                    roleEnum = Role.ADMINISTRATOR;
                }
                String userid = result.getString("userid");
                String mail = result.getString("email");
                String password = result.getString("password");
                String firstName = result.getString("firstname");
                String lastName = result.getString("lastname");
                String salt = result.getString("salt");
                person = new Person(userid, mail,password, firstName, lastName, salt, roleEnum);

            }
            if(person == null){
                throw new DbException("deze persoon bestaat niet");
            }
            return person;
        }

        catch (Exception e) {
            throw new DbException(e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }
    }

    @Override
    public void add(Person person, String role) {
        String sql = "INSERT INTO person (email, password, firstname, lastname, salt, role)" +
                " VALUES (?,?,?,?,?,?)";
        try {
            this.initializeConnection(sql);
            preparedStatement.setString(1, person.getEmail());
            preparedStatement.setString(2, person.getPassword());
            preparedStatement.setString(3, person.getFirstName());
            preparedStatement.setString(4, person.getLastName());
            preparedStatement.setString(5, person.getSalt());
            preparedStatement.setString(6, role);
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new DbException(e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }
    }

    @Override
    public void update(Person person) {
        String sql = "UPDATE r0368837_webontwerp.person SET email = ?,  firstname = ?, lastname = ? WHERE userid = ?";
        try  {
            this.initializeConnection(sql);
            preparedStatement.setString(1, person.getEmail());
            preparedStatement.setString(2, person.getFirstName());
            preparedStatement.setString(3,person.getLastName());
            preparedStatement.setInt(4, Integer.parseInt(person.getUserid()));
            preparedStatement.execute();

        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }
    }

    @Override
    public void delete(String personId) {
        String sql = "DELETE FROM r0368837_webontwerp.person WHERE userid = ?";
        try {this.initializeConnection(sql);
            preparedStatement.setInt(1, Integer.parseInt(personId));
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new DbException(e.getMessage(), e);
        }
        finally {
            this.closeConnection(preparedStatement);
        }

    }

}
