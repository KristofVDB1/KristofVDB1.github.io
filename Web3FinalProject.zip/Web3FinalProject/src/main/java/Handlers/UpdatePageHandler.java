package Handlers;

import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UpdatePageHandler extends RequestHandler {
    private ShopService service;

    public UpdatePageHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String destination = "updateProduct.jsp";
        request.setAttribute("updateProductCurrent", "current");
        request.setAttribute("id", request.getParameter("id"));
        request.setAttribute("product", service.getProduct(Integer.parseInt(request.getParameter("id"))));
        request.getRequestDispatcher(destination).forward(request, response);
    }
}
