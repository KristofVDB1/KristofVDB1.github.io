package Handlers;

import domain.Product;
import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class UpdateProductHandler extends RequestHandler {
    private ShopService service;

    public UpdateProductHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        ArrayList<String> errors = new ArrayList<>();
        int id = Integer.parseInt(request.getParameter("id"));
        Product product = service.getProduct(id);
        Product backup = product;
        setName(request, response, errors, product);
        setDescription(request, response, errors, product);
        setPrice(request, response, errors, product);
        if (errors.isEmpty()) {
            service.updateProducts(product);
            response.sendRedirect("Controller?action=overviewProduct");
        } else {
            product = backup;
            request.setAttribute("Errors", errors);
            response.sendRedirect("Controller?action=update");
        }
    }

    private void setPrice(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors,
                          Product product) {
        try {
            String price = request.getParameter("price");
            product.setPrice(price);
            request.setAttribute("prevprice", price);
        } catch (Exception e) {
            errors.add(e.getMessage());
        }
    }

    private void setDescription(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors,
                                Product product) {
        try {
            String description = request.getParameter("description");
            product.setDescription(description);
            request.setAttribute("prevdescription", description);
        } catch (Exception e) {
            errors.add(e.getMessage());
        }
    }

    private void setName(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors,
                         Product product) {
        try {
            String name = request.getParameter("name");
            product.setName(name);
            request.setAttribute("prevname", name);
        } catch (Exception e) {
            errors.add(e.getMessage());
        }
    }
}
