package Handlers;

import domain.ShopService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CookieHandler extends RequestHandler {


    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String origin = request.getParameter("page");
        String color = (String) request.getAttribute("color");
        System.out.println(color);
        Cookie c = new Cookie("color", color);
        if (c.getValue().equals("yellow")) {
            c.setValue("red");
        } else {
            c.setValue("yellow");
        }
        response.addCookie(c);
        response.sendRedirect("Controller?action=" + origin);
    }

}

