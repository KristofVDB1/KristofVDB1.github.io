package Handlers;

import domain.ShopService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DeleteProductHandler extends RequestHandler {
    private ShopService service;

    public DeleteProductHandler(ShopService service) {
        this.service = service;
    }
    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        service.deleteProduct(Integer.parseInt(request.getParameter("id")));
        response.sendRedirect("Controller?action=overviewProduct");
    }
}
