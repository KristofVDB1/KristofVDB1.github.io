package Handlers;

import domain.ShopService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DeleteProductPageHandler extends RequestHandler {
    private ShopService service;

    public DeleteProductPageHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String destination = "deleteProduct.jsp";
        request.setAttribute("deleteProductCurrent", "current");
        request.setAttribute("id", request.getParameter("id"));
        request.setAttribute("product", service.getProduct(Integer.parseInt(request.getParameter("id"))));
        request.getRequestDispatcher(destination).forward(request, response);

    }
}
