package Handlers;

import domain.Role;
import domain.ShopService;
import src.ui.CheckRoles;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class OverviewProductHandler extends RequestHandler {
    private ShopService service;

    public OverviewProductHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Role[] roles = {Role.ADMINISTRATOR, Role.NORMAL};
        CheckRoles.checkRole(request, roles);
        try {
            request.setAttribute("Products", this.service.getProducts());
        }
        catch (Exception e) {
            request.setAttribute("error", e.getMessage());
        }
        request.getRequestDispatcher("productoverview.jsp").forward(request, response);
    }
}
