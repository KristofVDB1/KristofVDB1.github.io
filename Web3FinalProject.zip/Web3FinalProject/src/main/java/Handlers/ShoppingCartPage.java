package Handlers;

import domain.Product;
import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCartPage extends RequestHandler {
    private ShopService service;

    public ShoppingCartPage(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String destination = "productoverviewOrdered.jsp";
        request.getRequestDispatcher(destination).forward(request, response);
    }
}
