package Handlers;

import domain.Person;
import domain.Role;
import domain.ShopService;
import src.ui.CheckRoles;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OverviewPersonsHandler extends RequestHandler {
    private ShopService service;

    public OverviewPersonsHandler(ShopService service) {
        this.service = service;
    }


    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Role[] roles = {Role.ADMINISTRATOR, Role.NORMAL};
        CheckRoles.checkRole(request, roles);
        String destination = "personoverview.jsp";
        request.setAttribute("persons",service.getPersons());
        request.getRequestDispatcher(destination).forward(request, response);
    }
}
