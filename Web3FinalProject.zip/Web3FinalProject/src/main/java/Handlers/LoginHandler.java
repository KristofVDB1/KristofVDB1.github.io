package Handlers;

import db.DbException;
import domain.DomainException;
import domain.Person;
import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginHandler extends RequestHandler {
    private ShopService service;
    Person person;
    private Cookie c;

    public LoginHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        List<String> errors = new ArrayList<>();
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        if (password == null) {
            errors.add("No password");
        }

        if (email == null) {
            errors.add("no email");
        }

        if (errors.size() == 0) {
            try {
                person = new Person();
                person = service.displayUser(email);
            } catch (NumberFormatException e) {
                throw new DomainException(e.getMessage());
            } catch (Exception e) {
                throw new DomainException(e.getMessage());
            }
            try {
                if (person != null && person.isCorrectPassword(password)) {
                    createSession(person, request);
                    System.out.println("creating session");
                } else {
                    errors.add("wrong password/email");
                }
            } catch (Exception e) {
                throw new DomainException(e.getMessage());
            }
        }

        if (errors.size() > 0) {
            request.setAttribute("errors", errors);
            try {
                person = service.displayUser(email);
            } catch (DbException e) {
                throw new DbException("No person found");
            }
            request.setAttribute("person", person);
        }
        request.setAttribute("errors", errors);
        response.sendRedirect("Controller?action=loginRedirect");
    }

    private void createSession(Person person, HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.setAttribute("person", person);
    }
}
