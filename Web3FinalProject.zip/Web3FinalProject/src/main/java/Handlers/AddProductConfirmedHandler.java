package Handlers;

import domain.Product;
import domain.ShopService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddProductConfirmedHandler extends RequestHandler {
    private Product product;
    private ShopService service;

    public AddProductConfirmedHandler(ShopService service) {
        this.product = new Product();
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        List<String> errors = checkInputValues(request, product);

        if(errors.size() > 0) {
            request.setAttribute("Errors", errors);
            RequestDispatcher view = request.getRequestDispatcher("addProduct.jsp");
            view.forward(request, response);
        } else {
            service.addProduct(product);
            response.sendRedirect("Controller?action=overviewProduct");
        }
    }

    private List<String> checkInputValues(HttpServletRequest request,Product product) {
        ArrayList<String> lijst = new ArrayList<String>();
        setPrice(request, lijst, product);
        setDescription(request, lijst, product);
        setName(request, lijst, product);
        return lijst;
    }

    private void setPrice(HttpServletRequest request, ArrayList<String> errors,
                          Product product) {
        try {
            String price = request.getParameter("price");
            product.setPrice(price);
            request.setAttribute("prevprice", price);
        } catch (Exception E) {
            errors.add(E.getMessage());
        }
    }

    private void setDescription(HttpServletRequest request,  ArrayList<String> errors,
                                Product product) {
        try {
            String description = request.getParameter("description");
            product.setDescription(description);
            request.setAttribute("prevdescription", description);
        } catch (Exception E) {
            errors.add(E.getMessage());
        }
    }

    private void setName(HttpServletRequest request,  ArrayList<String> errors,
                         Product product) {
        try {
            String name = request.getParameter("name");
            product.setName(name);
            request.setAttribute("prevname", name);
        } catch (Exception E) {
            errors.add(E.getMessage());
        }
    }
}
