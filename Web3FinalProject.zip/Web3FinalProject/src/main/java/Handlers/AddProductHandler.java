package Handlers;

import domain.Role;
import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.protocol.HttpContext;
import org.apache.http.protocol.HttpRequestHandler;
import src.ui.CheckRoles;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddProductHandler extends RequestHandler {

    public AddProductHandler() {

    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher("addProduct.jsp");
        Role[] roles = {Role.ADMINISTRATOR};
        CheckRoles.checkRole(request, roles);
        view.forward(request, response);
    }
}

