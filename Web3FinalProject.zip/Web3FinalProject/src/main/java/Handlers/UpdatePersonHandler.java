package Handlers;

import domain.Person;
import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class UpdatePersonHandler extends RequestHandler {
    private ShopService service;

    public UpdatePersonHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        ArrayList<String> errors = new ArrayList<>();
        String id = request.getParameter("id");
        Person person = service.getPerson(id);
        Person backup = person;
        setFirstName(request, response, errors, person);
        setLastName(request, response, errors, person);
        setEmail(request, response, errors, person);
        System.out.println(person.toString());
        if (errors.isEmpty()) {
            service.updatePerson(person);
            response.sendRedirect("Controller?action=overviewPersons");
        } else {
            person = backup;
            request.setAttribute("Errors", errors);
            response.sendRedirect("Controller?action=goToUpdatePerson");
        }
    }

    private void setEmail(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors,
                          Person person) {
        try {
            String email = request.getParameter("email");
            person.setEmail(email);
            request.setAttribute("prevemail", email);
        } catch (Exception E) {
            errors.add(E.getMessage());
        }
    }

    private void setLastName(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors,
                             Person person) {
        try {
            String lastname = request.getParameter("lastName");
            person.setLastName(lastname);
            request.setAttribute("prevlastName", lastname);
        } catch (Exception E) {
            errors.add(E.getMessage());
        }
    }

    private void setFirstName(HttpServletRequest request, HttpServletResponse response, ArrayList<String> errors,
                              Person person) {
        try {
            String firstname = request.getParameter("firstName");
            person.setFirstName(firstname);
            request.setAttribute("prevfirstName", firstname);
        } catch (Exception E) {
            errors.add(E.getMessage());
        }
    }
}
