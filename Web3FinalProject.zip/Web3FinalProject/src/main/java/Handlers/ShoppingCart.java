package Handlers;

import db.DbException;
import domain.Product;
import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCart extends RequestHandler {
    private ShopService service;

    public ShoppingCart(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        List<Product> products = this.service.getProducts();
        List<String> amounts = new ArrayList<>();
        for (int i = 1; i <products.size(); i++) {
            amounts.add(request.getParameter("amount"));
        }
        try {
            request.setAttribute("Products", products);
            request.setAttribute("amounts", amounts);
        }
        catch (Exception e) {
            throw new DbException("Geen producten beschikbaar");
        }

        System.out.println(amounts);
        String amount = request.getParameter("amount");
    }
}
