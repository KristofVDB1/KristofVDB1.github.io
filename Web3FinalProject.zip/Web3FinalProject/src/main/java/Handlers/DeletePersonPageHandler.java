package Handlers;

import db.DbException;
import domain.ShopService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DeletePersonPageHandler extends RequestHandler {
    private ShopService service;

    public DeletePersonPageHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        if (service.getPersons().size()> 2) {
            String destination = "deletePerson.jsp";
            request.setAttribute("deletePersonCurrent", "current");
            request.setAttribute("id", request.getParameter("id"));
            request.setAttribute("person", service.getPerson(request.getParameter("id")));
            request.getRequestDispatcher(destination).forward(request,response);
        }
        else {
            throw new DbException("Er zijn nog maar twee mensen aanwezig in de database");
        }

    }
}
