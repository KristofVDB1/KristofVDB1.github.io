package Handlers;

import domain.DomainException;
import domain.Person;
import domain.ShopService;
import domain.Role;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class signUpConfirmedHandler extends RequestHandler {
    private ShopService service;
    private Person person;

    public signUpConfirmedHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.createUser(request);
        List<String> errors = checkInputValues(request, person);
        if(errors.size() > 0) {try {
            request.setAttribute("errors", errors);
            request.setAttribute("person", person);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
            RequestDispatcher view = request.getRequestDispatcher("Controller?action=signUp");
            view.forward(request, response);
        } else {

            this.addUser(person, request);
            response.sendRedirect("Controller?action=overviewPersons");
        }

    }

    private void createUser(HttpServletRequest request) {
        try{
            this.person = new Person();
        } catch (Exception e){}
    }

    private List<String> checkInputValues(HttpServletRequest request, Person person){
        List<String> errorMessages = new ArrayList<>();
        checkUserFirstName(person, request, errorMessages);
        checkUserLastName(person, request, errorMessages);
        checkUserEmail(person, request, errorMessages);
        checkUserPassword(person, request, errorMessages);

        return errorMessages;
    }

    private void checkUserEmail(Person person, HttpServletRequest request, List<String> errorMessages) {
        String email = request.getParameter("email");
        try {
            person.setEmail(email);
        } catch (DomainException e) {
            errorMessages.add(e.getMessage());
        }
    }

    private void checkUserFirstName(Person person, HttpServletRequest request, List<String> errorMessages) {
        String name = request.getParameter("firstName");
        try {
            person.setFirstName(name);
        } catch (Exception e) {
            errorMessages.add(e.getMessage());
        }
    }

    private void checkUserLastName(Person person, HttpServletRequest request, List<String> errorMessages) {
        String name = request.getParameter("lastName");
        try {
            person.setLastName(name);
        } catch (Exception e) {
            errorMessages.add(e.getMessage());
        }
    }

    private void checkUserPassword(Person person, HttpServletRequest request, List<String> errorMessages) {
        String password = request.getParameter("password");
        password.trim();
        try {
            person.setPassword(password);
        } catch (Exception e) {
            errorMessages.add(e.getMessage());
        }
    }

    private void addUser(Person person, HttpServletRequest request){
        String role = request.getParameter("role");
        try {
            person.setHashedPassword(person.getPassword());
        } catch (DomainException e){ }
        try {
            service.addPerson(person,role);
        } catch (Exception e){ }
    }

}
