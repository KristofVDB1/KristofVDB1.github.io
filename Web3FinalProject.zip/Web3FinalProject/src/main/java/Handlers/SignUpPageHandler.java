package Handlers;

import domain.Role;
import domain.ShopService;
import src.ui.CheckRoles;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class SignUpPageHandler extends RequestHandler {
    private ShopService service;

    public SignUpPageHandler(ShopService service) {
        this.service = service;
    }

    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String destination = "signUp.jsp";
        Role[] roles = {Role.ADMINISTRATOR};
        CheckRoles.checkRole(request, roles);
        request.getRequestDispatcher(destination).forward(request, response);
    }
}
