package dbui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.swing.JOptionPane;

import domain.Person;
import domain.Role;

public class DesktopDb {
    public static void main(String[] args) throws SQLException {
        Properties properties = new Properties();
        String url = "jdbc:postgresql://gegevensbanken.khleuven.be:51617/2TX38?currentSchema=r0368837_webontwerp";

        properties.setProperty("user", "r0368837");
        properties.setProperty("password", "Klasfoto1007");
        properties.setProperty("ssl", "true");
        properties.setProperty("sslfactory", "org.postgresql.ssl.NonValidatingFactory");//wat is dit?

//		Class.forName("org.postgresql.Driver");
        String newfirstname = JOptionPane.showInputDialog("firstname?");
        String newlastname = JOptionPane.showInputDialog("lastname?");
        String newemail = JOptionPane.showInputDialog("email?");
        String newpassword = JOptionPane.showInputDialog("password?");
        int newuseridcount = 0;


        Connection connection = DriverManager.getConnection(url, properties);
        Statement statement;// connection maken en statement klaarzetten om te gebruiken


        statement = connection.createStatement();
        ResultSet result = statement.executeQuery("SELECT * FROM r0368837_webontwerp.person");
        while (result.next()) {
            int compareuserid = Integer.parseInt(result.getString("userid"));
            if(newuseridcount<=compareuserid){
                newuseridcount=compareuserid+1;
            }
        }
        statement.close();
        String newuserid = Integer.toString(newuseridcount); // tellen van aantal individuelen in de database om een nieuw userID te kunne toevoegen.


        statement = connection.createStatement();
        statement.execute("INSERT INTO r0368837_webontwerp.Person (userid, email, password, firstname, lastname) VALUES 	('"+newuserid+"','"+newemail+"','"+newpassword+"','"+newfirstname+"','"+newlastname+"');");
        statement.close();
        //execute, toevoegen van nieuw persoon/user aan de database

        statement = connection.createStatement();
        result = statement.executeQuery("SELECT * FROM r0368837_webontwerp.person");// resultset refreshen met nieuwe aangepaste database
        while (result.next()) {
            String userid = result.getString("userid");
            String email = result.getString("email");
            String password = result.getString("password");
            String firstname = result.getString("firstname");
            String lastname = result.getString("lastname");
            String salt = result.getString("salt");
            Role roleEnum = Role.NORMAL;
            if (result.getString("role").equals("administrator")) {
                roleEnum = Role.ADMINISTRATOR;
            }
            newuseridcount++;
            Person person = new Person(userid,email,password,firstname,lastname, salt, roleEnum);
            System.out.println(person);
        }
        //database uitprinten
        statement.close();
        connection.close();
        //connection met database en de statements afsluiten
    }

}
