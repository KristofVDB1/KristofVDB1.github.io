package src.ui;

import com.thoughtworks.selenium.condition.Not;
import domain.Person;
import domain.Role;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class CheckRoles {

    public static void checkRole( HttpServletRequest request, Role[] roles) throws NotAuthorizedException {
        try {
            HttpSession session = request.getSession();
            Person person = (Person) session.getAttribute("person");
            boolean value = false;
            for (Role r: roles) {
                if (person.getRole().equals(r)) {
                    value =true;
                }
            }

            if (value == false) {
                throw new NotAuthorizedException("no ty");
            }
        }
        catch (Exception e) {
            throw new NotAuthorizedException("YIKES, no");
        }
    }
}


