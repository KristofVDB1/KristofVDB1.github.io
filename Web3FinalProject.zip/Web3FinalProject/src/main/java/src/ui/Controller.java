package src.ui;

import Handlers.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/Controller")
public class Controller extends HttpServlet {
    private HandlerFactory handlerFactory = new HandlerFactory();
    private Cookie c;

    public Controller(){
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        cookieMethod(request,response);
        try {
            RequestHandler handler = handlerFactory.getHandler(action);
            handler.handleRequest(request, response);
        } catch (NotAuthorizedException e) {
            request.setAttribute("error", "Insufficient rights");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    private void cookieMethod(HttpServletRequest request, HttpServletResponse response) {
        if (request.getCookies()!= null) {
            for (Cookie q: request.getCookies()) {
                if (q.getName().equals("color")) {
                    c = q;
                    break;
                }
            }
        }

        if (c == null) {
            c= new Cookie("color","yellow");
        }

        String color = c.getValue();

        if (c.getValue().equals("yellow")|| c.getValue().equals("red")) {
            request.setAttribute("color", color);
            response.addCookie(c);
        }
    }
}
