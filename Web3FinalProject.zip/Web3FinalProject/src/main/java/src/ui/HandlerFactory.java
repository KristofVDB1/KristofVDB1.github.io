package src.ui;

import Handlers.AddProductHandler;
import Handlers.RequestHandler;
import Handlers.*;
import domain.ShopService;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialException;
import java.io.IOException;
import java.util.Properties;

public class HandlerFactory {
    private ShopService service = new ShopService();

    public HandlerFactory() {
    }

    public RequestHandler getHandler(String action  ) {
        if (action == null || action.isEmpty()) {
            action = "default";
        }

        switch (action) {
            case "addProduct":
                return new AddProductHandler();
            case "addProductConfirmed":
                return new AddProductConfirmedHandler(service);
            case "overviewProduct":
                return new OverviewProductHandler(service);
            case "login":
                return new LoginHandler(service);
            case "loginRedirect":
                return new LoginPageHandler();
            case "signUp":
                return new SignUpPageHandler(service);
            case "signUpConfirmed":
                return new signUpConfirmedHandler(service);
            case "overviewPersons":
                return new OverviewPersonsHandler(service);
            case "logout":
                return new LogoutHandler(service);
            case "goToDeleteProduct":
                return new DeleteProductPageHandler(service);
            case "deleteProduct":
                return new DeleteProductHandler(service);
            case"updateProduct":
                return new UpdateProductHandler(service);
            case "goToUpdateProduct":
                return new UpdatePageHandler(service);
            case"goToUpdatePerson":
                return new UpdatePersonPageHandler(service);
            case "updatePerson":
                return new UpdatePersonHandler(service);
            case "goToDeletePerson":
                return new DeletePersonPageHandler(service);
            case "deletePerson":
                return new DeletePersonHandler(service);
            case "switchColor":
                return new CookieHandler();
            case "goToTradingCart":
                return new ShoppingCartPage(service);
            case "finishTrading":
                return new ShoppingCart(service);
            case "changeColor":
                return new CookieHandler();
            default:
                return new IndexHandler();

        }
    }
}